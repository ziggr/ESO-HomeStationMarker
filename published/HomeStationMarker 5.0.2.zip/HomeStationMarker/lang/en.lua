HomeStationMarker.LANG = HomeStationMarker.LANG or {}
HomeStationMarker.LANG["en"] = {
  ["BANKER"     ] = "Tythis Andromo, the Banker"
, ["BANKER.2"   ] = "Ezabi the Banker"
, ["MERCHANT"   ] = "Nuzhimeh the Merchant"
, ["MERCHANT.2" ] = "Fezez the Merchant"
, ["FENCE"      ] = "Pirharri the Smuggler"

, ["APPRENTICE" ] = "The Apprentice"
, ["ATRONACH"   ] = "The Atronach"
, ["LADY"       ] = "The Lady"
, ["LORD"       ] = "The Lord"
, ["LOVER"      ] = "The Lover"
, ["MAGE"       ] = "The Mage"
, ["RITUAL"     ] = "The Ritual"
, ["SERPENT"    ] = "The Serpent"
, ["SHADOW"     ] = "The Shadow"
, ["STEED"      ] = "The Steed"
, ["THIEF"      ] = "The Thief"
, ["TOWER"      ] = "The Tower"
, ["WARRIOR"    ] = "The Warrior"
}
