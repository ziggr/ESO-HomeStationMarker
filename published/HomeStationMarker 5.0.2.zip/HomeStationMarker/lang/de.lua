HomeStationMarker.LANG = HomeStationMarker.LANG or {}
HomeStationMarker.LANG["de"] = {
  ["BANKER"     ] = "Tythis Andromo, the Banker"
, ["BANKER.2"   ] = "Ezabi the Banker"
, ["MERCHANT"   ] = "Nuzhimeh the Merchant"
, ["MERCHANT.2" ] = "Fezez the Merchant"
, ["FENCE"      ] = "Pirharri the Smuggler"

, ["APPRENTICE" ] = "der Lehrling"
, ["ATRONACH"   ] = "der Atronach"
, ["LADY"       ] = "die Fürstin"
, ["LORD"       ] = "der Fürst"
, ["LOVER"      ] = "die Liebende"
, ["MAGE"       ] = "die Magierin"
, ["RITUAL"     ] = "das Ritual"
, ["SERPENT"    ] = "die Schlange"
, ["SHADOW"     ] = "der Schatten"
, ["STEED"      ] = "das Schlachtross"
, ["THIEF"      ] = "die Diebin"
, ["TOWER"      ] = "der Turm"
, ["WARRIOR"    ] = "der Krieger"
}
