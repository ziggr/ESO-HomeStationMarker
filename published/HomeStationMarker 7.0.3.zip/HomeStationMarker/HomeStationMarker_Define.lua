HomeStationMarker                   = HomeStationMarker or {}
HomeStationMarker.name              = "HomeStationMarker"
