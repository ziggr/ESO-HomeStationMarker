HomeStationMarker.LANG = HomeStationMarker.LANG or {}
HomeStationMarker.LANG["fr"] = {
  ["BANKER"     ] = "Tythis Andromo, the Banker"
, ["BANKER.2"   ] = "Ezabi the Banker"
, ["MERCHANT"   ] = "Nuzhimeh the Merchant"
, ["MERCHANT.2" ] = "Fezez the Merchant"
, ["FENCE"      ] = "Pirharri the Smuggler"

, ["APPRENTICE" ] = "l’Apprenti"
, ["ATRONACH"   ] = "l’Atronach"
, ["LADY"       ] = "la Dame"
, ["LORD"       ] = "le Seigneur"
, ["LOVER"      ] = "l’Amant"
, ["MAGE"       ] = "le Mage"
, ["RITUAL"     ] = "le Rituel"
, ["SERPENT"    ] = "le Serpent"
, ["SHADOW"     ] = "l’Ombre"
, ["STEED"      ] = "le Destrier"
, ["THIEF"      ] = "le Voleur"
, ["TOWER"      ] = "la Tour"
, ["WARRIOR"    ] = "le Guerrier"
}
