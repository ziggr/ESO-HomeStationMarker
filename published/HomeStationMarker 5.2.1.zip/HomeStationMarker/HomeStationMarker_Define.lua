HomeStationMarker                   = HomeStationMarker or {}
HomeStationMarker.name              = "HomeStationMarker"
HomeStationMarker.version           = "5.0.1"
